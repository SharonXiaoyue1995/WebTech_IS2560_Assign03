/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import java.io.*;
import java.sql.*;

/**
 *
 * @author xiaoy
 */
public class DBconnector {

    public static String driver;
    public static String url;
    public static String user;
    public static String password;

    public static Connection conn = null;
    public Statement stmt;
    public ResultSet rs;

    static {
        try {
            driver = "org.apache.derby.jdbc.ClientDriver";
            url = "jdbc:derby://localhost:1527/XiaoyueShan";
            user = "IS2560";
            password = "IS2560";

            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public DBconnector() {
        this.conn = this.getConn();
    }

    public Connection getConn() {
        return this.conn;
    }

 

    //Search     
    public ResultSet doSelect(String sql) {
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
        } catch (SQLException sqlexception) {
            System.err.println("db.executeQuery: " + sqlexception.getMessage());
        }
        return rs;
    }
    
    
  /**  
   *   // reference from http://www.it610.com/article/2350602.htm 
       //Insert     
    public void doInsert(String sql) {
        try {
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
        } catch (SQLException sqlexception) {
            System.err.println("db.executeInset:" + sqlexception.getMessage());
        } finally {

        }
    }

    //Delete     
    public void doDelete(String sql) {
        try {
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
        } catch (SQLException sqlexception) {
            System.err.println("db.executeDelete:" + sqlexception.getMessage());
        }
    }

    //Update     
    public void doUpdate(String sql) {
        try {
            stmt = conn.createStatement();
            int i = stmt.executeUpdate(sql);
        } catch (SQLException sqlexception) {
            System.err.println("db.executeUpdate:" + sqlexception.getMessage());
        }
    }  */

}
 