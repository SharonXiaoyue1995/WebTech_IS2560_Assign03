/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;  
   
import bean.user;
import DB.DBconnector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author xiaoy
 */  
public class userdao {

    private Connection conn;
    private Statement st;
    private ResultSet rs=null;
    
    public boolean Login(user ur){  
        DBconnector db = new DBconnector();
        String sql1 = "select * from USERS where USERNAME = '"+ur.getName()+"'";
        String sql2 = "select * from USERS where PASSWORD = '"+ur.getPassword()+"'";
        rs = db.doSelect(sql1);
        try{
            if(rs.next()){
                rs =db.doSelect(sql2);
                if(rs.next()){
                    return true;
                }
            }
        } catch (SQLException error) {
            error.printStackTrace();
        }
        return false;
    }

}
/**
    public void Regirster(user ur){  
        DBconnector db = new DBconnector();
        String sql1 = "select * from USERS where USERNAME = '"+ur.getName()+"'";
        String sqlID= "select ID from USERS where ID = (select max(ID) from USERS))";
        INSERT INTO XiaoyueShan.DEMO (ID, PASSWORD,USERNAME) VALUES (sqlID +1, 'demo3')
        //String sql2 = "select * from USERS where PASSWORD = '"+ur.getPassword()+"'";
        rs = db.doInsert(sql1);

    }
}
*/    

